Links do Trabalho----------



Design Figma

https://www.figma.com/make/aHX77lpjT5dsP3rLSHLNGg/IT-Support-Ticket-System--Community-?node-id=0-1\&t=z2INlJlnkVJGtpbH-1



Teams

https://teams.live.com/l/invite/FAA9blO898ZL8dZ0QI?v=g1
